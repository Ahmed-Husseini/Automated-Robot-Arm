#include "stm32f103xb.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>

// ==== PIN DEFINITIONS ====
// Ultrasonic
#define TRIG_PIN     6   // PA6
#define ECHO_PIN     7   // PA7
#define DEBUG_PIN    14  // PB14

// Color sensor
#define LED_RED_PIN  12  // PB12
#define LED_BLUE_PIN 13  // PB13

// PCA9685
#define PCA9685_ADDRESS         0x80
#define PCA9685_MODE1           0x00
#define PCA9685_PRE_SCALE       0xFE
#define PCA9685_LED0_ON_L       0x06
#define PCA9685_MODE1_SLEEP_BIT 4
#define PCA9685_MODE1_AI_BIT    5
#define PCA9685_MODE1_RESTART_BIT 7

// ==== GLOBAL VARIABLES ====
volatile float distance_cm = 0;
volatile uint16_t capture1 = 0, capture2 = 0;
volatile uint8_t captured = 0;

// ==== UTILS ====
void delay_us(uint16_t us) {
    TIM1->CNT = 0;
    while (TIM1->CNT < us);
}

void delayMs(uint32_t ms) {
    vTaskDelay(pdMS_TO_TICKS(ms));
}

// ==== CLOCK CONFIG ====
void sys_clock_config(void) {
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY));
    RCC->CFGR |= RCC_CFGR_PLLSRC | RCC_CFGR_PLLMULL9;
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));
    FLASH->ACR |= FLASH_ACR_LATENCY_2;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while (!(RCC->CFGR & RCC_CFGR_SWS_PLL));
    SystemCoreClockUpdate();
}

// ==== GPIO INIT ====
void gpio_init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN;

    // PA6 - TRIG
    GPIOA->CRL &= ~(0xF << (4 * TRIG_PIN));
    GPIOA->CRL |=  (0x1 << (4 * TRIG_PIN));

    // PA7 - ECHO
    GPIOA->CRL &= ~(0xF << (4 * ECHO_PIN));
    GPIOA->CRL |=  (0x4 << (4 * ECHO_PIN));

    // PB14 - Debug LED
    GPIOB->CRH &= ~(0xF << (4 * (DEBUG_PIN - 8)));
    GPIOB->CRH |=  (0x1 << (4 * (DEBUG_PIN - 8)));

    // PA0 - TCS3200 OUT (input floating)
    GPIOA->CRL &= ~(GPIO_CRL_MODE0 | GPIO_CRL_CNF0);
    GPIOA->CRL |= GPIO_CRL_CNF0_0;

    // PA1–PA4 - S0–S3 (outputs)
    GPIOA->CRL |= (GPIO_CRL_MODE1_1 | GPIO_CRL_MODE2_1 |
                   GPIO_CRL_MODE3_1 | GPIO_CRL_MODE4_1);

    // Enable clock for GPIOB (if not already done)
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;

    // Configure PB12 and PB13 as input floating
    GPIOB->CRH &= ~(GPIO_CRH_MODE12 | GPIO_CRH_CNF12 |
                    GPIO_CRH_MODE13 | GPIO_CRH_CNF13);

    GPIOB->CRH |= (GPIO_CRH_CNF12_0 | GPIO_CRH_CNF13_0); // Input floating (CNF=01, MODE=00)


    // PB6, PB7 - I2C1 (alt function open-drain)
    GPIOB->CRL &= ~(GPIO_CRL_MODE6 | GPIO_CRL_CNF6 |
                    GPIO_CRL_MODE7 | GPIO_CRL_CNF7);
    GPIOB->CRL |= (GPIO_CRL_MODE6_1 | GPIO_CRL_CNF6_1 | GPIO_CRL_CNF6_0);
    GPIOB->CRL |= (GPIO_CRL_MODE7_1 | GPIO_CRL_CNF7_1 | GPIO_CRL_CNF7_0);
}

// ==== TIM CONFIG ====
void TIM1_us_init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
    TIM1->PSC = (SystemCoreClock / 1000000) - 1;
    TIM1->ARR = 0xFFFF;
    TIM1->CR1 |= TIM_CR1_CEN;
}

/*void TIM2_InputCapture_Config(void) {
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2->PSC = 71;
    TIM2->ARR = 0xFFFF;
    TIM2->CCMR1 = 0x01;
    TIM2->CCER = TIM_CCER_CC1E;
    TIM2->DIER |= TIM_DIER_CC1IE;
    TIM2->CR1 |= TIM_CR1_CEN;
    NVIC_EnableIRQ(TIM2_IRQn);
}

// ==== INTERRUPTS ====
void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_CC1IF) {
        if (!captured) capture1 = TIM2->CCR1, captured = 1;
        else capture2 = TIM2->CCR1, captured = 2;
        TIM2->SR &= ~TIM_SR_CC1IF;
    }
}*/

// ==== ULTRASONIC ====
float measure_distance(void) {
    GPIOA->BSRR = (1 << TRIG_PIN);
    delay_us(10);
    GPIOA->BRR = (1 << TRIG_PIN);

    while (!(GPIOA->IDR & (1 << ECHO_PIN)));
    uint32_t start = TIM1->CNT;
    while (GPIOA->IDR & (1 << ECHO_PIN));
    uint32_t end = TIM1->CNT;

    uint32_t diff = (end >= start) ? (end - start) : (0xFFFF - start + end);
    return (diff * 0.0343f) / 2.0f;
}

// ==== TCS3200 COLOR SENSOR ====
/*void set_color_filter(uint8_t s2, uint8_t s3) {
    if (s2) GPIOA->BSRR = GPIO_BSRR_BS3; else GPIOA->BSRR = GPIO_BSRR_BR3;
    if (s3) GPIOA->BSRR = GPIO_BSRR_BS4; else GPIOA->BSRR = GPIO_BSRR_BR4;
}

uint32_t measure_frequency(void) {
    captured = 0;
    while (captured < 2);
    uint16_t period_ticks = (capture2 > capture1) ? (capture2 - capture1) : (0xFFFF - capture1 + capture2);
    return (1000000UL / period_ticks);
}*/

// ==== I2C & PCA9685 ====
void I2C1_Init(void) {
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
    I2C1->CR1 &= ~I2C_CR1_PE;
    I2C1->CR2 = 36;
    I2C1->CCR = 180;
    I2C1->TRISE = 37;
    I2C1->CR1 |= I2C_CR1_PE;
}

void I2C1_Write(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint8_t len) {
    while (I2C1->SR2 & I2C_SR2_BUSY);
    I2C1->CR1 |= I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)); (void)I2C1->SR1;
    I2C1->DR = devAddr;
    while (!(I2C1->SR1 & I2C_SR1_ADDR)); (void)I2C1->SR2;
    I2C1->DR = regAddr;
    while (!(I2C1->SR1 & I2C_SR1_TXE));
    for (uint8_t i = 0; i < len; i++) {
        I2C1->DR = data[i];
        while (!(I2C1->SR1 & I2C_SR1_TXE));
    }
    I2C1->CR1 |= I2C_CR1_STOP;
}

void I2C1_Read(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint8_t len) {
    while (I2C1->SR2 & I2C_SR2_BUSY);
    I2C1->CR1 |= I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)); (void)I2C1->SR1;
    I2C1->DR = devAddr;
    while (!(I2C1->SR1 & I2C_SR1_ADDR)); (void)I2C1->SR2;
    I2C1->DR = regAddr;
    while (!(I2C1->SR1 & I2C_SR1_TXE));
    I2C1->CR1 |= I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)); (void)I2C1->SR1;
    I2C1->DR = devAddr | 0x01;
    while (!(I2C1->SR1 & I2C_SR1_ADDR)); (void)I2C1->SR2;
    for (uint8_t i = 0; i < len; i++) {
        if (i == len - 1) I2C1->CR1 &= ~I2C_CR1_ACK;
        while (!(I2C1->SR1 & I2C_SR1_RXNE));
        data[i] = I2C1->DR;
    }
    I2C1->CR1 |= I2C_CR1_STOP;
    I2C1->CR1 |= I2C_CR1_ACK;
}

void PCA9685_SetBit(uint8_t reg, uint8_t bit, uint8_t value) {
    uint8_t data;
    I2C1_Read(PCA9685_ADDRESS, reg, &data, 1);
    data = (value == 0) ? (data & ~(1 << bit)) : (data | (1 << bit));
    I2C1_Write(PCA9685_ADDRESS, reg, &data, 1);
    delayMs(1);
}

void PCA9685_SetPWMFrequency(uint16_t freq) {
    uint8_t prescale = (freq >= 1526) ? 3 : (freq <= 24) ? 255 : (uint8_t)(25000000 / (4096 * freq));
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_SLEEP_BIT, 1);
    I2C1_Write(PCA9685_ADDRESS, PCA9685_PRE_SCALE, &prescale, 1);
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_SLEEP_BIT, 0);
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_RESTART_BIT, 1);
}

void PCA9685_SetPWM(uint8_t ch, uint16_t on, uint16_t off) {
    uint8_t data[4] = { on & 0xFF, on >> 8, off & 0xFF, off >> 8 };
    I2C1_Write(PCA9685_ADDRESS, PCA9685_LED0_ON_L + 4 * ch, data, 4);
}

void PCA9685_SetServoAngle(uint8_t ch, float angle) {
    float val = (angle * (511.9 - 102.4) / 180.0f) + 102.4f;
    PCA9685_SetPWM(ch, 0, (uint16_t)val);
}

// ==== TASKS ====
void SensorTask(void* arg) {
    while (1) {
        distance_cm = measure_distance();
        if (distance_cm < 10.0f)
            GPIOB->BSRR = (1 << DEBUG_PIN);
        else
            GPIOB->BRR = (1 << DEBUG_PIN);
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

/*void vColorTask(void *pv) {
	uint32_t freq_r, freq_b;

	    while (1) {
	        // Red
	        set_color_filter(0, 0); // S2=0, S3=0 => Red
	        vTaskDelay(pdMS_TO_TICKS(100));
	        freq_r = measure_frequency();

	        // Blue
	        set_color_filter(0, 1); // S2=0, S3=1 => Blue
	        vTaskDelay(pdMS_TO_TICKS(100));
	        freq_b = measure_frequency();

	        // Determine dominant color and light LEDs
	        if (freq_r > freq_b) {
	            GPIOB->BSRR = GPIO_BSRR_BS12;  // Red LED ON
	            GPIOB->BSRR = GPIO_BSRR_BR13;  // Blue LED OFF
	        } else if (freq_b > freq_r) {
	            GPIOB->BSRR = GPIO_BSRR_BS13;  // Blue LED ON
	            GPIOB->BSRR = GPIO_BSRR_BR12;  // Red LED OFF
	        } else {
	            GPIOB->BSRR = GPIO_BSRR_BR12 | GPIO_BSRR_BR13; // Both OFF
	        }

	        vTaskDelay(pdMS_TO_TICKS(300));
	    }
}*/


void vServoTask(void *pv) {
    I2C1_Init(); PCA9685_SetPWMFrequency(50);
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_AI_BIT, 1);
    while (1) {
        PCA9685_SetServoAngle(0, 90);
        PCA9685_SetServoAngle(1, 30);
        PCA9685_SetServoAngle(2, 120);
        delayMs(1000);
        PCA9685_SetServoAngle(3, 180);
        delayMs(1000);

        PCA9685_SetServoAngle(1, 130);
        PCA9685_SetServoAngle(2, 90);
        delayMs(1000);
        while ((GPIOB->IDR & GPIO_IDR_IDR14)==0);
        PCA9685_SetServoAngle(3, 30);
        delayMs(1000);
        PCA9685_SetServoAngle(1, 30); // Color Measuring Position
        delayMs(3000);
`
        while((((GPIOB->IDR & GPIO_IDR_IDR12)==0) & ((GPIOB->IDR & GPIO_IDR_IDR13)==0)) | ((GPIOB->IDR & GPIO_IDR_IDR14)==0));
        delayMs(3000);
        if (GPIOB->IDR & GPIO_IDR_IDR12) {
            PCA9685_SetServoAngle(0, 180);
        } else {
            PCA9685_SetServoAngle(0, 0);
        }
        PCA9685_SetServoAngle(1, 100);
        PCA9685_SetServoAngle(2, 90);
        delayMs(1000);
        PCA9685_SetServoAngle(3, 180);
        delayMs(1000);
    }
}

// ==== MAIN ====
int main(void) {
    sys_clock_config();
    gpio_init();
    TIM1_us_init();
    //TIM2_InputCapture_Config();
    //GPIOA->BSRR = GPIO_BSRR_BS1 | GPIO_BSRR_BS2;  // S0, S1 = 1

    xTaskCreate(SensorTask, "Sensor", 128, NULL, 2, NULL);
    //xTaskCreate(vColorTask, "Color", 256, NULL, 1, NULL);
    xTaskCreate(vServoTask, "Servo", 256, NULL, 1, NULL);
    vTaskStartScheduler();
    while (1);
}
