#include "stm32f103xb.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>

// === Pin Definitions ===
#define TRIG_PIN 6     // PA6
#define ECHO_PIN 7     // PA7
#define DEBUG_PIN 14   // PB14

volatile float distance_cm = 0;

// === TIM1 Microsecond Delay ===
void TIM1_us_init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
    TIM1->PSC = (SystemCoreClock / 1000000) - 1;  // 1 MHz = 1 us tick
    TIM1->ARR = 0xFFFF;
    TIM1->CR1 |= TIM_CR1_CEN;
}

void delay_us(uint16_t us) {
    TIM1->CNT = 0;
    while (TIM1->CNT < us);
}

// === GPIO Init ===
void gpio_init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN;

    // PA6 - TRIG (Output)
    GPIOA->CRL &= ~(0xF << (4 * TRIG_PIN));
    GPIOA->CRL |=  (0x1 << (4 * TRIG_PIN));  // Output push-pull

    // PA7 - ECHO (Input floating)
    GPIOA->CRL &= ~(0xF << (4 * ECHO_PIN));
    GPIOA->CRL |=  (0x4 << (4 * ECHO_PIN));  // Input floating

    // PB14 - DEBUG LED (Output)
    GPIOB->CRH &= ~(0xF << (4 * (DEBUG_PIN - 8)));
    GPIOB->CRH |=  (0x1 << (4 * (DEBUG_PIN - 8)));  // Output push-pull
}

// === Ultrasonic Measurement ===
float measure_distance(void) {
    // Trigger pulse
    GPIOA->BSRR = (1 << TRIG_PIN);
    delay_us(10);
    GPIOA->BRR = (1 << TRIG_PIN);

    while (!(GPIOA->IDR & (1 << ECHO_PIN)));  // Wait for ECHO high
    uint32_t start = TIM1->CNT;
    while (GPIOA->IDR & (1 << ECHO_PIN));     // Wait for ECHO low
    uint32_t end = TIM1->CNT;

    uint32_t diff = (end >= start) ? (end - start) : (0xFFFF - start + end);
    float time_us = (float)diff;
    return (time_us * 0.0343f) / 2.0f;  // cm
}

// === FreeRTOS Tasks ===
void SensorTask(void* arg) {
    while (1) {
        distance_cm = measure_distance();

        if (distance_cm < 10.0f)
            GPIOB->BSRR = (1 << DEBUG_PIN);  // PB14 high
        else
            GPIOB->BRR = (1 << DEBUG_PIN);   // PB14 low

        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

// === Clock Setup ===
void sys_clock_config(void) {
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY));
    RCC->CFGR |= RCC_CFGR_PLLSRC | RCC_CFGR_PLLMULL9;
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));
    FLASH->ACR |= FLASH_ACR_LATENCY_2;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while (!(RCC->CFGR & RCC_CFGR_SWS_PLL));
    SystemCoreClockUpdate();
}

// === Main ===
int main(void) {
    sys_clock_config();
    gpio_init();
    TIM1_us_init();

    xTaskCreate(SensorTask, "Sensor", 128, NULL, 2, NULL);
    vTaskStartScheduler();
    while (1);
}
