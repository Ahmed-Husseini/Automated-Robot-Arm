#include "stm32f103xb.h"
#include "FreeRTOS.h"
#include "task.h"

volatile uint16_t capture1 = 0, capture2 = 0;
volatile uint8_t captured = 0;

// Function prototypes
void GPIO_Config(void);
void TIM2_InputCapture_Config(void);
void set_color_filter(uint8_t s2, uint8_t s3);
uint32_t measure_frequency(void);
void vColorTask(void *pvParameters);

void GPIO_Config(void) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN;

    // PA0: Input floating (TCS3200 OUT, TIM2_CH1)
    GPIOA->CRL &= ~(GPIO_CRL_MODE0 | GPIO_CRL_CNF0);
    GPIOA->CRL |= GPIO_CRL_CNF0_0; // Input floating

    // PA1–PA4: Output push-pull (S0–S3)
    GPIOA->CRL &= ~(GPIO_CRL_MODE1 | GPIO_CRL_CNF1 |
                    GPIO_CRL_MODE2 | GPIO_CRL_CNF2 |
                    GPIO_CRL_MODE3 | GPIO_CRL_CNF3 |
                    GPIO_CRL_MODE4 | GPIO_CRL_CNF4);

    GPIOA->CRL |= (GPIO_CRL_MODE1_1 |
                   GPIO_CRL_MODE2_1 |
                   GPIO_CRL_MODE3_1 |
                   GPIO_CRL_MODE4_1); // 2MHz output push-pull

    // PB12, PB13: Output push-pull (LEDs)
    GPIOB->CRH &= ~(GPIO_CRH_MODE12 | GPIO_CRH_CNF12 |
                    GPIO_CRH_MODE13 | GPIO_CRH_CNF13);
    GPIOB->CRH |= (GPIO_CRH_MODE12_1 | GPIO_CRH_MODE13_1); // 2MHz outputs
}


void TIM2_InputCapture_Config(void) {
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    TIM2->PSC = 71; // 72MHz / (71+1) = 1MHz -> 1us tick
    TIM2->ARR = 0xFFFF;
    TIM2->CCMR1 = 0x01; // CC1S = 01 -> input at IC1 mapped to TI1
    TIM2->CCER = 0x00;  // Reset CCER
    TIM2->CCER |= TIM_CCER_CC1E; // Enable capture on rising edge
    TIM2->DIER |= TIM_DIER_CC1IE; // Enable interrupt
    TIM2->CR1 |= TIM_CR1_CEN;

    NVIC_EnableIRQ(TIM2_IRQn);
}

void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_CC1IF) {
        if (!captured) {
            capture1 = TIM2->CCR1;
            captured = 1;
        } else {
            capture2 = TIM2->CCR1;
            captured = 2;
        }
        TIM2->SR &= ~TIM_SR_CC1IF;
    }
}

void set_color_filter(uint8_t s2, uint8_t s3) {
    if (s2) GPIOA->BSRR = GPIO_BSRR_BS3; // PA3 = S2
    else    GPIOA->BSRR = GPIO_BSRR_BR3;

    if (s3) GPIOA->BSRR = GPIO_BSRR_BS4; // PA4 = S3
    else    GPIOA->BSRR = GPIO_BSRR_BR4;
}


uint32_t measure_frequency(void) {
    captured = 0;
    while (captured < 2); // Wait for two edges

    uint16_t period_ticks = (capture2 > capture1) ? (capture2 - capture1) : (0xFFFF - capture1 + capture2);
    return (1000000UL / period_ticks); // Frequency in Hz
}

void vColorTask(void *pvParameters) {
    uint32_t freq_r, freq_b;

    while (1) {
        // Red
        set_color_filter(0, 0); // S2=0, S3=0 => Red
        vTaskDelay(pdMS_TO_TICKS(100));
        freq_r = measure_frequency();

        // Blue
        set_color_filter(0, 1); // S2=0, S3=1 => Blue
        vTaskDelay(pdMS_TO_TICKS(100));
        freq_b = measure_frequency();

        // Determine dominant color and light LEDs
        if (freq_r > freq_b) {
            GPIOB->BSRR = GPIO_BSRR_BS12;  // Red LED ON
            GPIOB->BSRR = GPIO_BSRR_BR13;  // Blue LED OFF
        } else if (freq_b > freq_r) {
            GPIOB->BSRR = GPIO_BSRR_BS13;  // Blue LED ON
            GPIOB->BSRR = GPIO_BSRR_BR12;  // Red LED OFF
        } else {
            GPIOB->BSRR = GPIO_BSRR_BR12 | GPIO_BSRR_BR13; // Both OFF
        }

        vTaskDelay(pdMS_TO_TICKS(300));
    }
}

int main(void) {
    GPIO_Config();
    TIM2_InputCapture_Config();

    // Enable S0, S1 = 1 (PA1, PA2) => scaling: 100%
    GPIOA->BSRR = GPIO_BSRR_BS1 | GPIO_BSRR_BS2;

    xTaskCreate(vColorTask, "ColorTask", 256, NULL, 1, NULL);
    vTaskStartScheduler();

    while (1); // Should never reach here
}
