#include "stm32f103xb.h"
#include "FreeRTOS.h"
#include "task.h"

#define PCA9685_ADDRESS         0x80 // I2C address for the PCA9685 with all address pins (A5–A0) set to 0
#define PCA9685_MODE1           0x00 // Address of the MODE1 register, used to configure global chip settings
#define PCA9685_PRE_SCALE       0xFE // Address of the prescaler register that sets the PWM frequency.
#define PCA9685_LED0_ON_L       0x06 // Base register address for controlling Channel 0's ON time low byte
#define PCA9685_MODE1_SLEEP_BIT 4    // Bit 4 of MODE1 register (Disables / Enables Clock)
#define PCA9685_MODE1_AI_BIT    5    // Bit 5 of MODE1 register (AI = Auto-Increment)
#define PCA9685_MODE1_RESTART_BIT 7  // Bit 7 of MODE1 register (triggers a restart sequence)

void delayMs(uint32_t ms) {
    vTaskDelay(pdMS_TO_TICKS(ms));
}

void I2C1_Init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    GPIOB->CRL &= ~(GPIO_CRL_MODE6 | GPIO_CRL_CNF6);
    GPIOB->CRL &= ~(GPIO_CRL_MODE7 | GPIO_CRL_CNF7);

    GPIOB->CRL |= (GPIO_CRL_MODE6_1 | GPIO_CRL_CNF6_1 | GPIO_CRL_CNF6_0); // PB6 = SCL
    GPIOB->CRL |= (GPIO_CRL_MODE7_1 | GPIO_CRL_CNF7_1 | GPIO_CRL_CNF7_0); // PB7 = SDA

    I2C1->CR1 &= ~I2C_CR1_PE;
    I2C1->CR2 = 36;          // Sets the peripheral input clock frequency (matches the APB1 clock = 36 MHz)
    I2C1->CCR = 180;         // Defines the I2C SCL clock frequency (100kHz)
    I2C1->TRISE = 37;        // max rise time
    I2C1->CR1 |= I2C_CR1_PE; // Enables the I2C1 peripheral after configuration is complete
}

void I2C1_Write(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint8_t len) {
    while (I2C1->SR2 & I2C_SR2_BUSY);
    I2C1->CR1 |= I2C_CR1_START;              // Start
    while (!(I2C1->SR1 & I2C_SR1_SB));
    (void)I2C1->SR1;
    I2C1->DR = devAddr;                      // Send Device Address
    while (!(I2C1->SR1 & I2C_SR1_ADDR));
    (void)I2C1->SR2;
    I2C1->DR = regAddr;                      // Send Register Address
    while (!(I2C1->SR1 & I2C_SR1_TXE));
    for (uint8_t i = 0; i < len; i++) {
        I2C1->DR = data[i];                  // Send Data (Byte)
        while (!(I2C1->SR1 & I2C_SR1_TXE));
    }
    I2C1->CR1 |= I2C_CR1_STOP;               // Stop
}

void I2C1_Read(uint8_t devAddr, uint8_t regAddr, uint8_t *data, uint8_t len) {
    while (I2C1->SR2 & I2C_SR2_BUSY);
    I2C1->CR1 |= I2C_CR1_START;              // Start
    while (!(I2C1->SR1 & I2C_SR1_SB));
    (void)I2C1->SR1;
    I2C1->DR = devAddr;                      // Read Device Address
    while (!(I2C1->SR1 & I2C_SR1_ADDR));
    (void)I2C1->SR2;
    I2C1->DR = regAddr;                      // Read Register Address
    while (!(I2C1->SR1 & I2C_SR1_TXE));
    I2C1->CR1 |= I2C_CR1_START;              // Start Again
    while (!(I2C1->SR1 & I2C_SR1_SB));
    (void)I2C1->SR1;
    I2C1->DR = devAddr | 0x01;               // Read Device Address
    while (!(I2C1->SR1 & I2C_SR1_ADDR));
    (void)I2C1->SR2;
    for (uint8_t i = 0; i < len; i++) {
        if (i == len - 1) I2C1->CR1 &= ~I2C_CR1_ACK;
        while (!(I2C1->SR1 & I2C_SR1_RXNE)); // Read and Store Data in Array
        data[i] = I2C1->DR;
    }
    I2C1->CR1 |= I2C_CR1_STOP;               // Stop
    I2C1->CR1 |= I2C_CR1_ACK;
}

void PCA9685_SetBit(uint8_t reg, uint8_t bit, uint8_t value) {  // Reads a byte from PCA9685 register, modifies a specific bit, then writes it back
    uint8_t data;                                               // Useful for setting SLEEP, RESTART, and AI bits in MODE1
    I2C1_Read(PCA9685_ADDRESS, reg, &data, 1);
    if (value == 0) data &= ~(1 << bit);
    else data |= (1 << bit);
    I2C1_Write(PCA9685_ADDRESS, reg, &data, 1);
    delayMs(1);
}

void PCA9685_SetPWMFrequency(uint16_t freq) {                   // Calculates prescaler value to generate the desired PWM frequency
                                                                // Puts PCA9685 to sleep, updates PRE_SCALE, wakes it up, and sets RESTART
    uint8_t prescale;
    if (freq >= 1526) prescale = 3;
    else if (freq <= 24) prescale = 255;
    else prescale = (uint8_t)(25000000 / (4096 * freq));
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_SLEEP_BIT, 1);
    I2C1_Write(PCA9685_ADDRESS, PCA9685_PRE_SCALE, &prescale, 1);
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_SLEEP_BIT, 0);
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_RESTART_BIT, 1);
}

void PCA9685_Init(uint16_t freq) {                              // Initializes PCA9685 with a given PWM frequency and sets Auto-Increment bit
    PCA9685_SetPWMFrequency(freq);
    PCA9685_SetBit(PCA9685_MODE1, PCA9685_MODE1_AI_BIT, 1);
}

void PCA9685_SetPWM(uint8_t ch, uint16_t on, uint16_t off) {    // Sets ON and OFF counter values for the specified channel
    uint8_t data[4];
    uint8_t reg = PCA9685_LED0_ON_L + 4 * ch;
    data[0] = on & 0xFF;
    data[1] = on >> 8;
    data[2] = off & 0xFF;
    data[3] = off >> 8;
    I2C1_Write(PCA9685_ADDRESS, reg, data, 4);
}

void PCA9685_SetServoAngle(uint8_t ch, float angle) {
    float val = (angle * (511.9 - 102.4) / 180.0f) + 102.4f;
    PCA9685_SetPWM(ch, 0, (uint16_t)val);
}

void vServoTask(void *pvParams) {
    I2C1_Init();
    PCA9685_Init(50);
    int n = 0;
    while (n < 5) {
        PCA9685_SetServoAngle(0, 90);
        PCA9685_SetServoAngle(1, 30);
        PCA9685_SetServoAngle(2, 120);
        delayMs(1000);
        PCA9685_SetServoAngle(3, 180);
        delayMs(1000);

        PCA9685_SetServoAngle(0, 90);
        PCA9685_SetServoAngle(1, 130);
        PCA9685_SetServoAngle(2, 90);
        delayMs(1000);
        PCA9685_SetServoAngle(3, 30);
        delayMs(1000);

        PCA9685_SetServoAngle(0, 90);
        PCA9685_SetServoAngle(1, 30);
        PCA9685_SetServoAngle(2, 120);
        delayMs(1000);

        if (n % 2 == 0){

        	PCA9685_SetServoAngle(0, 180);
        	PCA9685_SetServoAngle(1, 100);
        	PCA9685_SetServoAngle(2, 90);
        	delayMs(1000);
        	PCA9685_SetServoAngle(3, 180);
        	delayMs(1000);
        }

        else {

        	PCA9685_SetServoAngle(0, 0);
        	PCA9685_SetServoAngle(1, 100);
        	PCA9685_SetServoAngle(2, 90);
        	delayMs(1000);
        	PCA9685_SetServoAngle(3, 180);
        	delayMs(1000);
        }
        n++;
    }
}

int main(void) {
 // SystemInit();
    xTaskCreate(vServoTask, "ServoTask", 256, NULL, 1, NULL);
    vTaskStartScheduler();
    while (1);
}

void vApplicationMallocFailedHook(void) {
    while (1);
}

void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName) {
    (void)xTask;
    (void)pcTaskName;
    while (1);
}
